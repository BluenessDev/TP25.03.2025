package org.example.dev_avance_framework.factory;

import java.util.*;
import javax.xml.parsers.*;

import org.example.dev_avance_framework.actions.Action;
import org.w3c.dom.*;
import java.io.InputStream;

import org.example.dev_avance_framework.actions.ActionError;

public class MyFactory {
    public static Map<String, Class<? extends Action>> createActionMap() {
        Map<String, Class<? extends Action>> actionMap = new HashMap<>();
        try {
            InputStream xml = MyFactory.class.getClassLoader().getResourceAsStream("META-INF/actions-conf.xml");
            if (xml == null) {
                throw new IllegalStateException("Fichier META-INF/actions-conf.xml introuvable dans le classpath !");
            }
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(xml);
            NodeList nList = doc.getElementsByTagName("action");
            for (int i = 0; i < nList.getLength(); i++) {
                Element elem = (Element) nList.item(i);
                String name = elem.getAttribute("name");
                String className = elem.getAttribute("class");
                if (name == null || name.trim().isEmpty()) {
                    System.err.println("Action sans nom détectée dans le XML, ignorée.");
                    continue;
                }
                try {
                    Class<?> classe = Class.forName(className);
                    if (Action.class.isAssignableFrom(classe)) {
                        actionMap.put(name, classe.asSubclass(Action.class));
                    }
                } catch (ClassNotFoundException e) {
                    System.err.println("Classe non trouvée pour l'action '" + name + "' : " + className + ". Redirection vers ActionError.");
                    actionMap.put(name, (ActionError.class));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return actionMap;
    }
}