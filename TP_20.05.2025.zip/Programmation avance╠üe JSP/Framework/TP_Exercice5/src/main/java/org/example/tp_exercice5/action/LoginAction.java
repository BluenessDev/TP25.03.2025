package org.example.tp_exercice5.action;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.example.tp_exercice5.beans.UserBean;

import java.io.IOException;

public class LoginAction implements Action {
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String login = request.getParameter("login");
        String password = request.getParameter("password");

        if (login.equals("admin") && password.equals("admin")) {
            UserBean user = new UserBean();
            user.setLogin(login);
            user.setAttribut1("default1");
            user.setAttribut2("default2");
            request.getSession().setAttribute("user", user);
            return "page1.jsp";
        } else {
            return "erreur.jsp";
        }
    }
}