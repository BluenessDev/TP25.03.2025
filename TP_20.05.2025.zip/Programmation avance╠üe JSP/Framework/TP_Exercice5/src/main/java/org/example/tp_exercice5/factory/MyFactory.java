package org.example.tp_exercice5.factory;

import org.example.tp_exercice5.action.*;

import java.util.HashMap;
import java.util.Map;

public class MyFactory {
    public static Map<String, Class<?extends Action>> createActionMap() {
        Map<String, Class<?extends Action>> actions = new HashMap<>();
        actions.put("ActionDebut", ActionDebut.class);
        actions.put("LoginAction", LoginAction.class);
        actions.put("LogoutAction", LogoutAction.class);
        actions.put("ActionUn", ActionUn.class);
        return actions;
    }
}
