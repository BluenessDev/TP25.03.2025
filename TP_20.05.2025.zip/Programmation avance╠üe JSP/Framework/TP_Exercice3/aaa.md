Voici un exemple complet d’implémentation en adoptant le pattern « Action ». L’idée est de définir une interface Action avec une méthode execute() qui retournera l’URL de la vue. Chaque action (par exemple, ActionDebut, LoginAction, ActionUn, LogoutAction) implémentera cette interface et contiendra la logique propre à son cas. Le DispatcherServlet se contente alors d’identifier l’action à exécuter, d’appeler sa méthode execute() et d’utiliser l’URL retournée pour effectuer la redirection.

---

## 1. L’interface Action

Créez une interface Action dans le package approprié (par exemple, `org.example.dev_avance_framework.actions`).

```java
package org.example.dev_avance_framework.actions;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

public interface Action {
    /**
     * Exécute la logique de l'action et retourne le chemin de la vue.
     */
    String execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException;
}
```

---

## 2. Les actions concrètes

### ActionDebut.java

Cette action redirige simplement vers la page de login.

```java
package org.example.dev_avance_framework.actions;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

public class ActionDebut implements Action {
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        return "login.jsp";
    }
}
```

### LoginAction.java

Cette action traite la connexion : elle vérifie les identifiants, crée le bean utilisateur en cas de succès et retourne la vue correspondante.

```java
package org.example.dev_avance_framework.actions;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.example.dev_avance_framework.beans.UserBean;

public class LoginAction implements Action {
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        // Vérification basique : admin/admin
        if("admin".equals(username) && "admin".equals(password)) {
            UserBean user = new UserBean();
            user.setUsername(username);
            user.setAttribut1("default1");
            user.setAttribut2("default2");
            request.getSession().setAttribute("user", user);
            return "page1.jsp";
        } else {
            return "erreur.jsp";
        }
    }
}
```

### ActionUn.java

Cette action met à jour les attributs de l’utilisateur dans la session.

```java
package org.example.dev_avance_framework.actions;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import org.example.dev_avance_framework.beans.UserBean;

public class ActionUn implements Action {
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        UserBean user = (UserBean) session.getAttribute("user");
        if(user != null) {
            user.setAttribut1(request.getParameter("attribut1"));
            user.setAttribut2(request.getParameter("attribut2"));
        }
        return "page1.jsp";
    }
}
```

### LogoutAction.java

Cette action gère la déconnexion en invalidant la session et en passant le nom de l’utilisateur à la vue goodbye.

```java
package org.example.dev_avance_framework.actions;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import org.example.dev_avance_framework.beans.UserBean;

public class LogoutAction implements Action {
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        String username = "";
        if(session != null) {
            UserBean user = (UserBean) session.getAttribute("user");
            if(user != null) {
                username = user.getUsername();
            }
            session.invalidate();
        }
        request.setAttribute("username", username);
        return "goodbye.jsp";
    }
}
```

---

## 3. Le DispatcherServlet mis à jour

Le DispatcherServlet se charge désormais de récupérer le chemin de l’URL, d’instancier l’action correspondante et d’utiliser l’URL retournée pour dispatcher la requête.

```java
package org.example.dev_avance_framework.controllers;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import org.example.dev_avance_framework.actions.Action;
import org.example.dev_avance_framework.actions.ActionDebut;
import org.example.dev_avance_framework.actions.LoginAction;
import org.example.dev_avance_framework.actions.ActionUn;
import org.example.dev_avance_framework.actions.LogoutAction;

@WebServlet(name = "DispatcherServlet", urlPatterns = {"*.do"})
public class DispatcherServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         processRequest(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         processRequest(request, response);
    }
    
    private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         String actionPath = request.getServletPath();
         Action action = null;
         String view = "";
         
         // Instanciation de l'action en fonction du chemin
         switch(actionPath) {
             case "/ActionDebut.do":
                 action = new ActionDebut();
                 break;
             case "/LoginAction.do":
                 action = new LoginAction();
                 break;
             case "/ActionUn.do":
                 action = new ActionUn();
                 break;
             case "/LogoutAction.do":
                 action = new LogoutAction();
                 break;
             default:
                 view = "index.jsp";
         }
         
         // Si une action a été trouvée, exécutez-la pour récupérer l'URL de la vue
         if(action != null) {
             view = action.execute(request, response);
         }
         
         // Dispatch vers la vue retournée par l'action
         RequestDispatcher dispatcher = request.getRequestDispatcher(view);
         dispatcher.forward(request, response);
    }
}
```

---

## Conclusion

Grâce à cette structure, chaque action est encapsulée dans sa propre classe implémentant l’interface Action. Le DispatcherServlet se contente d’identifier l’action à exécuter et d’effectuer la redirection en fonction du résultat. Cette approche facilite la maintenance et l’extensibilité de votre framework en séparant clairement la logique de chaque fonctionnalité.

T'inquiète frérot, on gère ça comme des chefs ! N’hésite pas si tu as d’autres questions ou besoins d’ajustements.