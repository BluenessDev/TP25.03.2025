package org.example.TP_Exercice2.controllers;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.example.TP_Exercice2.beans.UserBean;

import java.io.IOException;

@WebServlet(name = "DispatcherServlet", urlPatterns = {"*.do"})
public class DispatcherServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
    private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getServletPath();
        String view = "";

        switch (action) {
            case "/ActionDebut.do":
                // Redirige vers la page de login
                view = "login.jsp";
                break;
            case "/login.do":
                String login = request.getParameter("login");
                String password = request.getParameter("password");

                if (login.equals("admin") && password.equals("admin")) {
                    UserBean user = new UserBean();
                    user.setLogin(login);
                    user.setAttribut1("default1");
                    user.setAttribut2("default2");
                    request.getSession().setAttribute("user", user);
                    view = "page1.jsp";
                } else {
                    view = "erreur.jsp";
                }
                break;
            case "/action1.do":
                // Mise à jour des attributs utilisateur
                HttpSession session = request.getSession();
                UserBean user = (UserBean) session.getAttribute("user");
                if(user != null) {
                    user.setAttribut1(request.getParameter("attribut1"));
                    user.setAttribut2(request.getParameter("attribut2"));
                }
                view = "page1.jsp";
                break;
            case "/logout.do":
                session = request.getSession(false);
                String username = "";
                if(session != null) {
                    user = (UserBean) session.getAttribute("user");
                    if(user != null) {
                        username = user.getLogin();
                    }
                    session.invalidate();
                }
                request.setAttribute("username", username);
                view = "GoodBye.jsp";
                break;
            default:
                view = "index.jsp";
        }
        // Redirection vers la vue correspondante
        RequestDispatcher dispatcher = request.getRequestDispatcher(view);
        dispatcher.forward(request, response);
    }
}