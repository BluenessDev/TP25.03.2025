package org.example.tp_exercice5.controllers;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.example.tp_exercice5.action.*;
import org.example.tp_exercice5.factory.MyFactory;


import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class DispatcherServlet extends HttpServlet {

    private Map<String, Class<? extends Action>> actionMap;

    @Override
    public void init() throws ServletException {
        // Utilisation de la factory pour créer la map d'actions
        actionMap = MyFactory.createActionMap();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String path = request.getServletPath();
        String actionName = path.substring(1, path.lastIndexOf(".do"));

        Action action = null;
        String view = "";

        // Récupération de la classe associée dans la map via la factory
        Class<? extends Action> actionClass = actionMap.get(actionName);
        if(actionClass != null) {
            try {
                // Instanciation dynamique de l'action
                action = actionClass.newInstance();
                // Exécution de l'action pour récupérer l'URL de la vue
                view = action.execute(request, response);
            } catch (InstantiationException | IllegalAccessException e) {
                throw new ServletException("Erreur lors de l'instanciation de l'action : " + actionName, e);
            }
        } else {
            // Si l'action n'est pas trouvée
            view = "index.jsp";
        }

        // Dispatch vers la vue retournée par l'action
        RequestDispatcher dispatcher = request.getRequestDispatcher(view);
        dispatcher.forward(request, response);
    }
}