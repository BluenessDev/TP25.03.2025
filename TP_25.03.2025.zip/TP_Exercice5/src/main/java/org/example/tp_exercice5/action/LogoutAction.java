package org.example.tp_exercice5.action;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.example.tp_exercice5.beans.UserBean;

import java.io.IOException;

public class LogoutAction implements Action {
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        String username = "";
        if(session != null) {
            UserBean user = (UserBean) session.getAttribute("user");
            if(user != null) {
                username = user.getLogin();
            }
            session.invalidate();
        }
        request.setAttribute("username", username);
        return "goodbye.jsp";
    }
}